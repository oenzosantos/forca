#include <vector>
#include <string>

void salva_arquivo(std::vector<std::string> nova_lista);