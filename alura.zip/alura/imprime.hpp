void imprime_cabecalho();
void imprime_palavra();
void imprime_erros();